// Copyright 2011 Emilie Gillet.
//
// Author: Emilie Gillet (emilie.o.gillet@gmail.com)
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include "controller/midi_dispatcher.h"
#include "controller/multi.h"

#include <avr/interrupt.h>

#include "controller/resources.h"

namespace ambika {

/* extern */
Multi multi;

/* <static> */
MultiData Multi::data_;
Part Multi::parts_[kNumParts];
uint16_t Multi::clock_counter_ = 0;
uint16_t Multi::lfo_refresh_counter_ = 0;
uint8_t Multi::lfo_refresh_cycle_ = 0;
volatile uint8_t Multi::num_clock_events_;
uint16_t Multi::tick_duration_;
uint8_t Multi::tick_count_;
uint8_t Multi::step_count_;
uint8_t Multi::running_;
uint8_t Multi::idle_ticks_;
uint16_t Multi::tick_duration_table_[kNumStepsInGroovePattern];
uint8_t Multi::flags_;
uint8_t Multi::launchkey_play_button_note_ = 60;
bool Multi::launchkey_play_button_note_active_ = false;
/* </static> */

static constexpr MultiData::Parameters init_settings PROGMEM {
  // Parts mappings.
  .part_mapping = {
    {1, 0, 127, 0x15},
    {2, 0, 127, 0x2a},
    {3, 0, 127, 0},
    {4, 0, 127, 0},
    {5, 0, 127, 0},
    {6, 0, 127, 0},
  },

  // Clock.
  .clock_bpm = 120,
  .clock_groove_template = 0,
  .clock_groove_amount = 0,
  .clock_release = 4,

  // Performance page assignments.
  .knob_assignment = {
    {0, 1, 0},
    {0, 16, 0},
    {1, 1, 0},
    {1, 16, 0},
    {0, 22, 0},
    {0, 42, 0},
    {1, 22, 0},
    {1, 42, 0},
  },

  // Padding.
  .padding2 = {0, 0, 0, 0}
};

/* static */
void Multi::Init(bool force_reset) {
  for (uint8_t i = 0; i < kNumParts; ++i) {
    parts_[i].Init();
  }
  // Force a reset to factory settings.
  if (force_reset) {
    InitSettings(INITIALIZATION_DEFAULT);
    Storage::WriteMultiToEeprom();
  } else {
    if (!Storage::LoadMultiFromEeprom()) {
      InitSettings(INITIALIZATION_DEFAULT);
      Storage::WriteMultiToEeprom();
    } else {
      Touch();
    }
  }
  running_ = 0;
}

/* static */
void Multi::InitSettings(InitializationMode mode) {
  ResourcesManager::Load(&init_settings, 0, data_.params_addr());
  for (uint8_t i = 0; i < kNumParts; ++i) {
    parts_[i].InitSettings(mode);
  }
  Touch();
}

/* static */
uint8_t Multi::SolveAllocationConflicts(uint8_t constraint) {
  uint8_t available_voices = 0xff;
  for (uint8_t i = 0; i < kNumParts; ++i) {
    if (i != constraint) {
      uint8_t& part_i_allocation = data_.part_mapping(i).voice_allocation;
      part_i_allocation &= available_voices;
      available_voices &= byteInverse(part_i_allocation);
    }
  }
  return available_voices;
}

/* static */
void Multi::AssignVoicesToParts() {
  for (uint8_t i = 0; i < kNumParts; ++i) {
    parts_[i].AssignVoices(data_.part_mapping(i).voice_allocation);
  }
}

/* KZ MODs Sync Prts workaroud & Part Mutes */
/* static */
void Multi::SyncPartClocks() {
    for (uint8_t i = 0; i < kNumParts; ++i) {
        parts_[i].Start();
    }
}

/* KZ MODs Mute parts from the performance page */
/* static */
#ifndef DISABLE_PART_MUTES
void Multi::ToggleMute(uint8_t part) {
    parts_[part].ToggleMute();
}
#endif

/* static */
void Multi::Touch() {
  ComputeInternalClockOverflowsTable();
  SolveAllocationConflicts(-1);
  AssignVoicesToParts();
  flags_ = FLAG_HAS_CHANGE;
}

const int32_t kTempoFactor = (4 * kSampleRateNum * 60L / 24L / kSampleRateDen);

/* static */
void Multi::ComputeInternalClockOverflowsTable() {
  static_assert(kTempoFactor == 392156L);

  int32_t rounding = 2 * data_.clock_bpm();
  int32_t denominator = 4 * data_.clock_bpm();
  int16_t base_tick_duration = (kTempoFactor + rounding) / denominator;
  for (uint8_t i = 0; i < kNumStepsInGroovePattern; ++i) {
    int32_t swing_direction = ResourcesManager::Lookup<int16_t, uint8_t>(
        LUT_RES_GROOVE_SWING + data_.clock_groove_template(), i);
    swing_direction *= base_tick_duration;
    swing_direction *= data_.clock_groove_amount();
    int16_t swing = highWord(swing_direction);
    tick_duration_table_[i] = base_tick_duration + swing;
  }
  tick_duration_ = tick_duration_table_[0];
}

/* static */
void Multi::Clock() {
  // This is used by the internal clock, and to get a global pulse for the 
  // incoming clock.
  ++tick_count_;
  if (tick_count_ == kNumTicksPerStep) {
    tick_count_ = 0;
    ++step_count_;
    if (step_count_ == kNumStepsInGroovePattern) {
      step_count_ = 0;
    }
    tick_duration_ = tick_duration_table_[step_count_];
  }
  
  if (running_)  {
    for (uint8_t i = 0; i < kNumParts; ++i) {
      if (parts_[i].SequencerModeChanged()) {
        SyncPartClocks();
        break;
      }
    }
    // Advance the clock of all parts, and check if some of them are idle.
    midi_dispatcher.OnClock();
    uint8_t idle = 1;
    for (uint8_t i = 0; i < kNumParts; ++i) {
      parts_[i].Clock();
      if (parts_[i].num_pressed_keys() > 0) {
        idle = 0;
      }
    }
    // No key is being pressed on any part. It looks like we are counting beats
    // for nothing...
    if (internal_clock()) {
      if (idle) {
        ++idle_ticks_;
      } else {
        idle_ticks_ = 0;
      }
      if (idle_ticks_ > U8U8Mul(data_.clock_release(), 24)) {
        Stop();
      }
    }
  }
}

/* static */
void Multi::Start() {
  midi_dispatcher.OnStart();
  tick_count_ = 0;
  step_count_ = 0;
  idle_ticks_ = 0;
  for (uint8_t i = 0; i < kNumParts; ++i) {
    parts_[i].Start();
  }
  tick_duration_ = tick_duration_table_[0];
  running_ = 1;
}

/* static */
void Multi::Stop() {
  midi_dispatcher.OnStop();
  for (uint8_t i = 0; i < kNumParts; ++i) {
    parts_[i].Stop();
  }
  running_ = 0;
}

/* static */
void Multi::UpdateClocks() {
  while (lfo_refresh_counter_ >= kControlRate) {
    ++lfo_refresh_cycle_;
    lfo_refresh_counter_ -= kControlRate;
    for (uint8_t i = 0; i < kNumParts; ++i) {
      parts_[i].UpdateLfos(lfo_refresh_cycle_ & 1);
    }
  }
  
  // Snapshot ticks generated by the ISR-based clock atomically. A foreground
  // decrement can otherwise overwrite an interrupt increment on AVR.
  uint8_t pending_clock_events;
  uint8_t old_sreg = SREG;
  cli();
  pending_clock_events = num_clock_events_;
  num_clock_events_ = 0;
  SREG = old_sreg;

  if (internal_clock()) {
    while (pending_clock_events--) {
      Clock();
    }
  }
}

/* static */
void Multi::SetValue(uint8_t address, uint8_t value) {
  auto bytes = data_.bytes();
  if (bytes[address] != value) {
    bytes[address] = value;
    flags_ |= FLAG_HAS_USER_CHANGE;
    if (address < PRM_MULTI_CLOCK_BPM) {
      if (byteAnd(address, 3) == 3) {
        Touch();
      }
    } else if (address <= PRM_MULTI_CLOCK_GROOVE_AMOUNT) {
      ComputeInternalClockOverflowsTable();
    }
  }
}

}  // namespace ambika
